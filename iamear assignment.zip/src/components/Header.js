import React from 'react';
import '../css/Header.css'


class Header extends React.Component {

    render() {
        return (
            <div className="Header">
            <span>Event Viewer</span>
            </div>
        );
    }

}

export default Header;
