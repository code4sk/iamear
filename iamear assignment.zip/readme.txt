This project is part of iamears assignment. It is a single page react app.

In order to run this project first download the project in your system. 
Make sure that you have nodejs already installed in your system.


Then go to the project using command line. For eg, "cd iamears assignment"


Then run the command "npm install", this will install all packages needed to 
run this application. This process may take some time.


Finally, to run the application, run the command "npm start".
This will open the application on localhost.


In case any thing does not work, can mail me at "kapoorshubham098@gmail.com"

Thanks for reading :)